﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sabre
{
    class EasterEgg
    {
        public EasterEgg(EasterEggType type, MainWindow mw)
        {
            if(type == EasterEggType.Doggo)
            {
                
            }
        }
        public enum EasterEggType
        {
            Doggo,
            Crauzer,
            Brokoli,
            Chewy,
            Yurixy,
            Leischii
        }
    }
}
